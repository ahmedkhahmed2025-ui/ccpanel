package com.zertic.quicktools;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import org.json.JSONObject;

/**
 * Quick Tools
 *
 * A small WebView-hosted control panel offering device convenience actions:
 * flashlight toggle, opening the system camera, screen brightness, a QR
 * scanner hand-off, battery status, and basic device info.
 *
 * Deliberately NOT included: Device Administrator privileges, remote/hidden
 * camera or screen access, screen lock, screen recording, or power controls.
 * Every action here is user-initiated, visible on-screen, and affects only
 * the device the app is running on, while it is running in the foreground.
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "QuickTools";
    private static final int REQUEST_CAMERA_PERMISSION = 100;
    private static final int REQUEST_TAKE_PHOTO = 101;
    private static final int REQUEST_WRITE_SETTINGS = 102;

    private WebView webView;
    private CameraManager cameraManager;
    private String flashCameraId;
    private boolean isFlashOn = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        cameraManager = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
        findFlashCameraId();

        webView = findViewById(R.id.webView);
        setupWebView();
        webView.loadUrl("file:///android_asset/index.html");
    }

    private void setupWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        // No remote navigation needed; this keeps the bridge scoped to our own page.
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new DeviceBridge(), "DeviceBridge");
    }

    private void findFlashCameraId() {
        try {
            for (String id : cameraManager.getCameraIdList()) {
                CameraCharacteristics c = cameraManager.getCameraCharacteristics(id);
                Boolean hasFlash = c.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing = c.get(CameraCharacteristics.LENS_FACING);
                if (hasFlash != null && hasFlash && facing != null
                        && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    flashCameraId = id;
                    break;
                }
            }
        } catch (CameraAccessException e) {
            Log.e(TAG, "Unable to enumerate cameras", e);
        }
    }

    // ---------------------------------------------------------------------
    // JavaScript bridge: every method here is a single, visible, on-device
    // action triggered directly by the person tapping a button in index.html.
    // ---------------------------------------------------------------------
    public class DeviceBridge {

        @JavascriptInterface
        public String toggleFlashlight() {
            if (flashCameraId == null) {
                return result(false, "No flashlight available on this device.");
            }
            if (ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.CAMERA)
                    != PackageManager.PERMISSION_GRANTED) {
                runOnUiThread(() -> ActivityCompat.requestPermissions(
                        MainActivity.this, new String[]{Manifest.permission.CAMERA},
                        REQUEST_CAMERA_PERMISSION));
                return result(false, "Camera permission needed for the flashlight.");
            }
            try {
                isFlashOn = !isFlashOn;
                cameraManager.setTorchMode(flashCameraId, isFlashOn);
                return result(true, isFlashOn ? "Flashlight on" : "Flashlight off");
            } catch (CameraAccessException e) {
                Log.e(TAG, "Flashlight toggle failed", e);
                return result(false, "Could not toggle the flashlight.");
            }
        }

        /**
         * Opens the SYSTEM camera app via a standard Intent so the user takes
         * their own photo through the normal camera UI. This app never
         * accesses the camera feed directly or silently.
         */
        @JavascriptInterface
        public String takePhoto() {
            runOnUiThread(() -> {
                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(takePictureIntent, REQUEST_TAKE_PHOTO);
                } else {
                    Toast.makeText(MainActivity.this, "No camera app found.", Toast.LENGTH_SHORT).show();
                }
            });
            return result(true, "Opening camera app");
        }

        /**
         * Sets screen brightness for this app's window (0-100). This does not
         * require WRITE_SETTINGS or change the device-wide brightness.
         */
        @JavascriptInterface
        public String setBrightness(int percent) {
            int clamped = Math.max(1, Math.min(100, percent));
            float value = clamped / 100f;
            runOnUiThread(() -> {
                WindowManager.LayoutParams layoutParams = getWindow().getAttributes();
                layoutParams.screenBrightness = value;
                getWindow().setAttributes(layoutParams);
            });
            return result(true, "Brightness set to " + clamped + "%");
        }

        /**
         * Hands off to a dedicated barcode/QR scanning app via Intent, rather
         * than implementing covert camera access in this app. If no scanner
         * is installed, sends the user to install one.
         */
        @JavascriptInterface
        public String scanQrCode() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent("com.google.zxing.client.android.SCAN");
                    intent.putExtra("SCAN_MODE", "QR_CODE_MODE");
                    if (intent.resolveActivity(getPackageManager()) != null) {
                        startActivityForResult(intent, 103);
                    } else {
                        Intent marketIntent = new Intent(Intent.ACTION_VIEW,
                                Uri.parse("market://details?id=com.google.zxing.client.android"));
                        startActivity(marketIntent);
                    }
                } catch (Exception e) {
                    Log.e(TAG, "QR scan hand-off failed", e);
                }
            });
            return result(true, "Opening QR scanner");
        }

        @JavascriptInterface
        public String getBatteryStatus() {
            try {
                IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
                Intent batteryStatus = registerReceiver(null, filter);
                int level = batteryStatus != null
                        ? batteryStatus.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
                int scale = batteryStatus != null
                        ? batteryStatus.getIntExtra(BatteryManager.EXTRA_SCALE, -1) : -1;
                int status = batteryStatus != null
                        ? batteryStatus.getIntExtra(BatteryManager.EXTRA_STATUS, -1) : -1;
                boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                        || status == BatteryManager.BATTERY_STATUS_FULL;

                int pct = (level >= 0 && scale > 0) ? Math.round(level * 100f / scale) : -1;

                JSONObject json = new JSONObject();
                json.put("percent", pct);
                json.put("charging", charging);
                return json.toString();
            } catch (Exception e) {
                Log.e(TAG, "Battery status failed", e);
                return result(false, "Could not read battery status.");
            }
        }

        @JavascriptInterface
        public String getDeviceInfo() {
            try {
                JSONObject json = new JSONObject();
                json.put("model", Build.MODEL);
                json.put("manufacturer", Build.MANUFACTURER);
                json.put("androidVersion", Build.VERSION.RELEASE);
                json.put("sdkInt", Build.VERSION.SDK_INT);
                return json.toString();
            } catch (Exception e) {
                return result(false, "Could not read device info.");
            }
        }

        private String result(boolean success, String message) {
            try {
                JSONObject json = new JSONObject();
                json.put("success", success);
                json.put("message", message);
                return json.toString();
            } catch (Exception e) {
                return "{\"success\":false,\"message\":\"Internal error\"}";
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                            @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CAMERA_PERMISSION
                && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Camera permission granted. Try again.", Toast.LENGTH_SHORT).show();
        }
    }
}
